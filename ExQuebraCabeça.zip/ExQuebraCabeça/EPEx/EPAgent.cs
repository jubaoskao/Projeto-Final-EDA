using System;
using System.Collections;
using System.Diagnostics;
using System.Collections.Generic;
using ProjetoGrafos.DataStructure;
using System.Linq;

namespace EP
{
    public class EightPuzzle : Graph
    {
        readonly static int[,] moves = { {+1,-2},{+2,-1},{+2,+1},{+1,+2},
                                        {-1,+2},{-2,+1},{-2,-1},{-1,-2} };

        public string Solucao(int l, int c)
        {
            int Linha = l;
            int Coluna = c;
            string passeio = "";
            int[,] board = new int[Linha, Coluna];
            Graph graph = new Graph();
            board.Initialize();

            int x = 0,                    
                y = 0;

            List<Node> list = new List<Node>(Linha * Coluna);
            Node antigo = new Node(x.ToString() + y.ToString(), x, y);
            list.Add(antigo);
            graph.AddNode(antigo.Name, x, y);

            while (list.Count < Linha * Coluna)
            {
                if (Move_Possible(board, x, y, Linha, Coluna))
                {
                    int move = board[x, y];
                    board[x, y]++;
                    x += moves[move, 0];
                    y += moves[move, 1];
                    Node novo = new Node(x.ToString() + y.ToString(), x, y);
                    graph.AddNode(novo.Name, x, y);
                    graph.AddEdge(antigo.Name, novo.Name, 1);
                    list.Add(novo);
                    antigo = novo;
                }
                else
                {
                    if (board[x, y] >= 8)
                    {
                        board[x, y] = 0;
                        Node removido = list[list.Count - 1];
                        list.RemoveAt(list.Count - 1);
                        graph.RemoveNode(removido.Name);
                        try
                        {
                            antigo = graph.Nodes[graph.Nodes.Length - 1];
                            if (list.Count == 0)
                            {
                                return ("N�o existe caminho");
                            }
                            x = list[list.Count - 1].X;
                            y = list[list.Count - 1].Y;
                        }
                        catch (Exception e)
                        {
                            return ("N�o existe caminho");
                        }
                        
                    }
                    board[x, y]++;
                }
            }

            int last_x = list[0].X,
                last_y = list[0].Y;
            string letters = "ABCDEFGH";
            bool first = true;
            for (int i = 1; i < list.Count; i++)
            {
                if (first)
                {
                    passeio += (string.Format("{0,2}", "") + letters[list[i].X] + (list[i].Y + 1)) + ", ";
                    first = false;
                }
                else
                {
                    if (i != list.Count - 1)
                        passeio += (string.Format("{0,2}", "") + letters[list[i].X] + (list[i].Y + 1)) + ", ";
                    else
                        passeio += (string.Format("{0,2}", "") + letters[list[i].X] + (list[i].Y + 1));
                }

                last_x = list[i].X;
                last_y = list[i].Y;
            }

            //bool first = true;
            //foreach (Node item in graph.Nodes)
            //{
            //    foreach (Edge item2 in item.Edges)
            //    {
            //        if (item2.To != null)
            //        {
            //            passeio += item2.To.X.ToString() + item2.To.Y.ToString() + ", ";
            //        }
            //    }
            //}
            //string xx = FormataPasseio(passeio);
            return passeio;
        }

        public string FormataPasseio(string pas)
        {
            string b = new string(pas.ToCharArray().Where(x => !Char.IsWhiteSpace(x)).ToArray());
            string a = new string(b.ToCharArray().Where(x => !(",").Contains(x)).ToArray());
            string f = "";
            char[] bx = a.ToCharArray();
            for (int i = 0; i < bx.Length; i += 2)
            {
                if (i == bx.Length - 2)
                {
                    f += Convert.ToChar(bx[i] + 17) + (bx[i + 1] - 47).ToString();
                }
                else
                {
                    f += Convert.ToChar(bx[i] + 17) + (bx[i + 1] - 47).ToString() + ",";
                }
            }

            return f;
        }

        static bool Move_Possible(int[,] board, int cur_x, int cur_y, int linha, int coluna)
        {
            if (board[cur_x, cur_y] >= 8)
                return false;

            int new_x = cur_x + moves[board[cur_x, cur_y], 0],
                new_y = cur_y + moves[board[cur_x, cur_y], 1];

            if (new_x >= 0 && new_x < linha && new_y >= 0 && new_y < coluna && board[new_x, new_y] == 0)
                return true;

            return false;
        }
    }
}

